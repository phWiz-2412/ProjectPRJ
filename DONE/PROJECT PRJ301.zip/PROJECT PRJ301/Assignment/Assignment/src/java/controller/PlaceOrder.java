package controller;

import dal.DAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Users;

import java.io.IOException;

@WebServlet("/place-order")
public class PlaceOrder extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (req.getSession().getAttribute("acc") == null){
            resp.sendRedirect("login");
        } else {
            Users user = (Users) req.getSession().getAttribute("acc");
            int result = new DAO().order(user.getUserID());
            String err_mess = "";
            String success_mess = "";
            if (result == -1 ){
                err_mess = "Out of stock";
            } else if (result == 0){
                err_mess = "Server error";
            } else {
                success_mess = "Place order success";
            }
            if(!err_mess.isEmpty()){
                resp.sendRedirect(req.getContextPath() + "/cart?err=" + err_mess);
            } else {
                resp.sendRedirect(req.getContextPath() + "/cart?success=" + success_mess);
            }
        }
    }
}
