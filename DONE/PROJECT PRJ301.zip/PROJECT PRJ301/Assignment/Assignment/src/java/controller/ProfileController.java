package controller;

import dal.DAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Customer;
import model.Users;

import java.io.IOException;

@WebServlet("/profile")
public class ProfileController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (req.getSession().getAttribute("acc") == null){
            resp.sendRedirect(req.getContextPath() + "/login");
        } else {
            Users user = (Users) req.getSession().getAttribute("acc");
            Customer customer = new DAO().getCustomer(user.getUserID());
            req.setAttribute("customer", customer);
            req.getRequestDispatcher("/profile.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int customerID = Integer.parseInt(req.getParameter("customerID"));
        String fullName = req.getParameter("fullName");
        String email = req.getParameter("email");
        String phoneNumber = req.getParameter("phoneNumber");
        String address = req.getParameter("address");

        Customer updatedCustomer = new Customer();
        updatedCustomer.setCustomerID(customerID);
        updatedCustomer.setFullName(fullName);
        updatedCustomer.setEmail(email);
        updatedCustomer.setPhoneNumber(phoneNumber);
        updatedCustomer.setAddress(address);

        new DAO().updateCustomer(updatedCustomer);
        resp.sendRedirect(req.getContextPath() + "/profile");
    }
}
