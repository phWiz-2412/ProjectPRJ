/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dal.DAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Users;
import model.Comments;
import org.apache.catalina.User;

/**
 *
 * @author Thanh
 */
@WebServlet("/comment")
public class CommentController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        // Get the current logged-in user
        HttpSession session = request.getSession();
        Users user = (Users) session.getAttribute("acc");

        if (user == null) {
            // Redirect to login if not logged in
            response.sendRedirect("Login.jsp");
            return;
        }

        String productId = request.getParameter("productId");
        String commentText = request.getParameter("commentText");
        String ratingStr = request.getParameter("rating");

        try {
            int prodId = Integer.parseInt(productId);
            int rating = Integer.parseInt(ratingStr);

            DAO dao = new DAO();

            int customerId = dao.getCustomerId(user.getUserID());

            if (customerId == 0) {
                request.setAttribute("errorMessage", "Customer record not found");
                request.getRequestDispatcher("detail?ProductID=" + productId).forward(request, response);
                return;
            }

            int deliveredOrders = dao.getDeliveredOrdersCount(user.getUserID(), productId);
            int existingComments = dao.getUserCommentsCount(customerId, productId);

            if (existingComments >= deliveredOrders) {
                request.setAttribute("errorMessage", "You have already reviewed all your purchases of this product");
                request.getRequestDispatcher("detail?ProductID=" + productId).forward(request, response);
                return;
            }

            Comments comment = new Comments(
                    customerId,
                    prodId,
                    commentText,
                    rating,
                    new java.sql.Timestamp(new java.util.Date().getTime())
            );

            dao.addComment(comment);

            response.sendRedirect("detail?ProductID=" + productId);

        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Invalid input data");
            request.getRequestDispatcher("detail?ProductID=" + productId).forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Comment Controller for handling product reviews";
    }// </editor-fold>

}
