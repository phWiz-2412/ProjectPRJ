package dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBContext {
    protected Connection connection;

    public DBContext() {
        try {
            String url = "jdbc:sqlserver://localhost\\LAPTOP-Q7H2DF3I\\SQLEXPRESS:1433;databaseName=Assignment;encrypt=false;trustServerCertificate=true";
            String user = "sa";
            String password = "123";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(url, user, password);
            
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            
        }
    }

    public Connection getConnection() {
        return connection;
    }
    
}
