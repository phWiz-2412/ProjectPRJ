package model;

import java.sql.Timestamp;

public class Comments {
    private int commentId;
    private int customerId;
    private int productId;
    private String commentText;
    private int rating;
    private Timestamp commentDate;

    public Comments() {
    }


    public Comments(int commentId, int customerId, int productId, String commentText, int rating, Timestamp commentDate) {
        this.commentId = commentId;
        this.customerId = customerId;
        this.productId = productId;
        this.commentText = commentText;
        this.rating = rating;
        this.commentDate = commentDate;
    }


    public Comments(int customerId, int productId, String commentText, int rating, Timestamp commentDate) {
        this.customerId = customerId;
        this.productId = productId;
        this.commentText = commentText;
        this.rating = rating;
        this.commentDate = commentDate;
    }

    public int getCommentId() {
        return commentId;
    }

    public void setCommentId(int commentId) {
        this.commentId = commentId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getCommentText() {
        return commentText;
    }

    public void setCommentText(String commentText) {
        this.commentText = commentText;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        if (rating >= 1 && rating <= 5) { 
            this.rating = rating;
        } else {
            throw new IllegalArgumentException("Rating must be between 1 and 5");
        }
    }

    public Timestamp getCommentDate() {
        return commentDate;
    }

    public void setCommentDate(Timestamp commentDate) {
        this.commentDate = commentDate;
    }

    @Override
    public String toString() {
        return "Comments{" +
                "commentId=" + commentId +
                ", customerId=" + customerId +
                ", productId=" + productId +
                ", commentText='" + commentText + '\'' +
                ", rating=" + rating +
                ", commentDate=" + commentDate +
                '}';
    }
}