package model;

import java.sql.Timestamp;

public class Customer {
    private int CustomerID;
    private String FullName;
    private String Email;
    private String PhoneNumber;
    private String Address;
    private Timestamp RegistrationDate;
    private int UserID;

    public Customer(int customerID, String fullName, String email, String phoneNumber, String address, Timestamp registrationDate, int userID) {
        CustomerID = customerID;
        FullName = fullName;
        Email = email;
        PhoneNumber = phoneNumber;
        Address = address;
        RegistrationDate = registrationDate;
        UserID = userID;
    }

    public Customer() {
    }

    public int getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(int customerID) {
        CustomerID = customerID;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String fullName) {
        FullName = fullName;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public Timestamp getRegistrationDate() {
        return RegistrationDate;
    }

    public void setRegistrationDate(Timestamp registrationDate) {
        RegistrationDate = registrationDate;
    }

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int userID) {
        UserID = userID;
    }
}
