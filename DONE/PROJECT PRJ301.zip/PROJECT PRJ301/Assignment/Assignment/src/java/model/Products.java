/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;





/**
 *
 * @author Thanh
 */
public class Products {
    private int ProductID;
    private String ProductName;
    private String Brand;
    
    private double Price;
   
    private String Description;
    private String ImageURL;
    private int stock;

    public Products() {
    }

    public Products(int ProductID, String ProductName, String Brand, double Price, String Description, String ImageURL) {
        this.ProductID = ProductID;
        this.ProductName = ProductName;
        this.Brand = Brand;
        this.Price = Price;
        this.Description = Description;
        this.ImageURL = ImageURL;
    }
    
    public Products(int ProductID, String ProductName, String Brand, double Price, String Description, String ImageURL, int stock) {
        this.ProductID = ProductID;
        this.ProductName = ProductName;
        this.Brand = Brand;
        this.Price = Price;
        this.Description = Description;
        this.ImageURL = ImageURL;
        this.stock = stock;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    public String getBrand() {
        return Brand;
    }

    public void setBrand(String Brand) {
        this.Brand = Brand;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getImageURL() {
        return ImageURL;
    }

    public void setImageURL(String ImageURL) {
        this.ImageURL = ImageURL;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    
    

    @Override
    public String toString() {
        return "Products{" + "ProductID=" + ProductID + ", ProductName=" + ProductName + ", Brand=" + Brand + ", Price=" + Price + ", Description=" + Description + ", ImageURL=" + ImageURL + '}';
    }

    
    }

   

    

