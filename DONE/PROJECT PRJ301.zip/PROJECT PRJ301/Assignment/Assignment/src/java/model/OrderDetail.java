package model;

public class OrderDetail {
    private int OrderDetailId;
    private int OrderId;
    private Products Product;
    private int quantity;
    private double price;

    public OrderDetail(int orderDetailId, int orderId, Products product, int quantity, double price) {
        OrderDetailId = orderDetailId;
        OrderId = orderId;
        Product = product;
        this.quantity = quantity;
        this.price = price;
    }

    public OrderDetail(int orderDetailId, int orderId, int quantity, double price) {
        OrderDetailId = orderDetailId;
        OrderId = orderId;
        this.quantity = quantity;
        this.price = price;
    }

    public int getOrderDetailId() {
        return OrderDetailId;
    }

    public void setOrderDetailId(int orderDetailId) {
        OrderDetailId = orderDetailId;
    }

    public int getOrderId() {
        return OrderId;
    }

    public void setOrderId(int orderId) {
        OrderId = orderId;
    }

    public Products getProduct() {
        return Product;
    }

    public void setProduct(Products product) {
        Product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
