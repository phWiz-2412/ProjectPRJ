package controller;

import dal.DAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Order;
import model.Users;

import java.io.IOException;
import java.util.List;

@WebServlet("/admin/order")
public class AdminOrderController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (req.getSession().getAttribute("acc") == null){
            resp.sendRedirect(req.getContextPath() + "/login");
        } else {
            if (((Users) req.getSession().getAttribute("acc")).getRole().equals("Customer")){
                resp.sendRedirect(req.getContextPath() + "/login");
            } else {
                List<Order> orders = new DAO().getAllOrders();
                req.setAttribute("orders", orders);
                req.getRequestDispatcher("/AdminOrder.jsp").forward(req, resp);
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (req.getSession().getAttribute("acc") == null){
            resp.sendRedirect(req.getContextPath() + "/login");
        } else {
            if (((Users) req.getSession().getAttribute("acc")).getRole().equals("Customer")){
                resp.sendRedirect(req.getContextPath() + "/login");
            } else {
                String status = req.getParameter("status");
                String orderId = req.getParameter("orderId");
                new DAO().updateOrderStatus(orderId, status);
                resp.sendRedirect(req.getContextPath() + "/admin/order");
            }
        }
    }
}
/*
admin: xem danh sách ng dùng, quản lý product (thêm, xóa, sửa), quản lý đơn hàng (xem, thay đổi trạng thái)
user: xem danh sách sản phẩm, tìm kiếm sản phẩm, thêm giỏ hàng (session, db), checkout, xem đơn hàng đã đặt
* */
/*
admin: xem danh sách ng dùng, quản lý product (thêm, xóa, sửa), quản lý đơn hàng (xem, thay đổi trạng thái)
user: login,logout,register, xem danh sách sản phẩm, tìm kiếm sản phẩm, thêm giỏ hàng (session, db), checkout, xem đơn hàng đã đặt
* */
