package model;

import java.sql.Timestamp;
import java.util.List;

public class Order {
    private int OrderId;
    private Users user;
    private Timestamp OrderDate;
    private Double TotalAmount;
    private String Status;
    private List<OrderDetail> orderDetails;

    public Order(int orderId, Users user, Timestamp orderDate, Double totalAmount, String status, List<OrderDetail> orderDetails) {
        OrderId = orderId;
        this.user = user;
        OrderDate = orderDate;
        TotalAmount = totalAmount;
        Status = status;
        this.orderDetails = orderDetails;
    }

    public Order(int orderId, Users user, Timestamp orderDate, Double totalAmount, String status) {
        OrderId = orderId;
        this.user = user;
        OrderDate = orderDate;
        TotalAmount = totalAmount;
        Status = status;
    }

    public int getOrderId() {
        return OrderId;
    }

    public void setOrderId(int orderId) {
        OrderId = orderId;
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public Timestamp getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(Timestamp orderDate) {
        OrderDate = orderDate;
    }

    public Double getTotalAmount() {
        return TotalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        TotalAmount = totalAmount;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public List<OrderDetail> getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(List<OrderDetail> orderDetails) {
        this.orderDetails = orderDetails;
    }
}
