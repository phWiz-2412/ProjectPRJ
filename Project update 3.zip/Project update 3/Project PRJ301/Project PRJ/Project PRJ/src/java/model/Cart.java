package model;

import java.sql.Timestamp;

public class Cart {
    private int CartId;
    private int CustomerID;
    private int ProductID;
    private int Quantity;
    private Timestamp DateAdded;
    private Products Products;

    public Cart(int customerID, int productID, int quantity, Timestamp date) {
        CustomerID = customerID;
        ProductID = productID;
        Quantity = quantity;
        DateAdded = date;
    }

    public Cart(int productID, int quantity, Timestamp dateAdded) {
        ProductID = productID;
        Quantity = quantity;
        DateAdded = dateAdded;
    }

    public Cart(int productID, int quantity, Timestamp dateAdded, model.Products products) {
        ProductID = productID;
        Quantity = quantity;
        DateAdded = dateAdded;
        Products = products;
    }

    public Cart(int cartId, int customerID, int productID, int quantity, Timestamp dateAdded) {
        CartId = cartId;
        CustomerID = customerID;
        ProductID = productID;
        Quantity = quantity;
        DateAdded = dateAdded;
    }

    public Cart(int cartId, int customerID, int productID, int quantity, Timestamp dateAdded, model.Products products) {
        CartId = cartId;
        CustomerID = customerID;
        ProductID = productID;
        Quantity = quantity;
        DateAdded = dateAdded;
        Products = products;
    }

    public Timestamp getDateAdded() {
        return DateAdded;
    }

    public void setDateAdded(Timestamp dateAdded) {
        DateAdded = dateAdded;
    }

    public model.Products getProducts() {
        return Products;
    }

    public void setProducts(model.Products products) {
        Products = products;
    }

    public int getCartId() {
        return CartId;
    }

    public void setCartId(int cartId) {
        CartId = cartId;
    }

    public int getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(int customerID) {
        CustomerID = customerID;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int productID) {
        ProductID = productID;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }

    public Timestamp getDate() {
        return DateAdded;
    }

    public void setDate(Timestamp date) {
        DateAdded = date;
    }
}
