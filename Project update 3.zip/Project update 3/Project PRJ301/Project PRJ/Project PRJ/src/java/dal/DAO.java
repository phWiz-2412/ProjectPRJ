
package dal;

import java.sql.*;

import java.util.ArrayList;

import java.util.List;

import model.*;
import org.apache.catalina.User;

public class DAO {
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    
    public List<Products> getAllProducts() {
         List<Products>  list = new ArrayList<>();
         String query = "select*from Products";
         try {
            conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
            list.add( new Products(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getString(5), rs.getString(6)));
            }
        } catch (Exception e) {
        }
        return list;
    }
    public List<Category> getAllCategory() {
         List<Category>  list = new ArrayList<>();
         String query = "select*from Category";
         try {
            conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
            list.add(new Category(rs.getInt(1), rs.getString(2)));
            }
        } catch (Exception e) {
        }
        return list;
    }
    public Products getLast(){
        String query = "select top 1*from Products\n" 
                    + "order by ProductID desc";
        try {
           conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
                return  new Products(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getString(5), rs.getString(6));
            }
        } catch (Exception e) {
        }
        return null;
}
    public List<Products> getAllProductByCID(String CategoryID) {
         List<Products>  list = new ArrayList<>();
         String query = "select *from Products\n" +
                            "where CategoryID = ?";
         try {
            conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            ps.setString(1, CategoryID);
            rs = ps.executeQuery();
            while(rs.next()){
            list.add( new Products(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getString(5), rs.getString(6)));
            }
        } catch (Exception e) {
        }
        return list;
    }
    public Products getProductByCID(String ProductID) {
        
         String query = "select *from Products\n" +
                            "where ProductID = ?";
         try {
            conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            ps.setString(1, ProductID);
            rs = ps.executeQuery();
            while(rs.next()){
            return  new Products(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getString(5), rs.getString(6));
            }
        } catch (Exception e) {
        }
        return null;
}
    public List<Products> searchByName(String txtSearch) {
         List<Products>  list = new ArrayList<>();
         String query = "select *from Products\n" +
                            "where ProductName like ?";
         try {
            conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            ps.setString(1, "%"+txtSearch+"%");
            rs = ps.executeQuery();
            while(rs.next()){
             list.add( new Products(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getString(5), rs.getString(6)));
            }
        } catch (Exception e) {
        }
        return list;
}
        public Users login(String UserName, String Passrowd){
            String query = "select *from Users\n" +
                            "where UserName = ?\n" +
                            "and [Password] =?";
            try {
               conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            ps.setString(1, UserName);
            ps.setString(2, Passrowd); 
            rs = ps.executeQuery();
                while (rs.next()){
                    return new Users(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
                    
                }
            } catch (Exception e) {
            }

            
            return null;
        }
       public Users checkUserExist(String UserName){
            String query = "select *from Users\n" +
                            "where UserName = ?\n" 
                           ;
            try {
               conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            ps.setString(1, UserName);
             
            rs = ps.executeQuery();
                while (rs.next()){
                    return new Users(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
                    
                }
            } catch (Exception e) {
            }

            
            return null;
        } 
       public  void signup(String UserName, String Password){
           String query = "insert into Users\n" +
                            "values(?,?,'Customer')";
           try {
               conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            ps.setString(1, UserName);
            ps.setString(2, Password);
            ps.executeUpdate();
            
           } catch (Exception e) {
           }
       }
       public void deleteProduct( String ProductID){
           String query = "delete from Products\n" +
                    "where ProductID =?";
           try {
                conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            ps.setString(1, ProductID);
            ps.executeUpdate();
           } catch (Exception e) {
           }
       }
       public void insertProduct(String ProductName, String ImageURL,String Price, String Brand, String Description, String CategoryID ){
           String query ="insert [dbo].[Products]([ProductName], [ImageURL], [Price], [Brand], [Description], [CategoryID])  \n" +
                        "values(?,?,?,?,?,?)";
           try {
            conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            ps.setString(1, ProductName);
            ps.setString(2, ImageURL);
            ps.setString(3, Price);
            ps.setString(4, Brand);
            ps.setString(5, Description);
            ps.setString(6, CategoryID);
            ps.executeUpdate();
           } catch (Exception e) {
           }}
           public void editProduct(String ProductName, String ImageURL,String Price, String Brand, String Description, String CategoryID, String ProductID ){
           String query ="update Products\n" +
                            "set [ProductName] = ?,\n" +
                            "ImageURL = ?,\n" +
                            "Price =?,\n" +
                            "Brand = ?,\n" +
                            "[Description] =?,\n" +
                            "CategoryID = ?\n" +
                            "where ProductID =?";
           try {
            conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            ps.setString(1, ProductName);
            ps.setString(2, ImageURL);
            ps.setString(3, Price);
            ps.setString(4, Brand);
            ps.setString(5, Description);
            ps.setString(6, CategoryID);
            ps.setString(7, ProductID);
            ps.executeUpdate();
           } catch (Exception e) {
           }
           }
           public List<Users> getAllUser() {
         List<Users>  list = new ArrayList<>();
         String query = "select*from Users";
         try {
            conn = new DBContext().getConnection();
            ps= conn.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
            list.add( new Users(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
            }
        } catch (Exception e) {
        }
        return list;
       }
            public void add2Cart(Cart cart) {
        try {
            String sql = "insert into Cart(CustomerID, ProductID, Quantity, DateAdded) VALUES (?, ?, ?, ?);";
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, cart.getCustomerID());
            ps.setInt(2, cart.getProductID());
            ps.setInt(3, cart.getQuantity());
            ps.setTimestamp(4, cart.getDate());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getCustomerId(int userId) {
        try {
            String sql = "select CustomerID from Customers where UserID = ?;";
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            } else {
                return 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public List<Cart> getCartOfCustomer(int userId) {
        try {
            String sql = "select Cart.*, Products.* from Cart inner join Products on Cart.ProductID = Products.ProductID where CustomerID = (select CustomerID from Customers where UserID = ?);";
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            rs = ps.executeQuery();
            List<Cart> list = new ArrayList<>();
            while (rs.next()) {
                list.add(new Cart(
                        rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getTimestamp(5),
                        new Products(
                                rs.getInt(6),
                                rs.getString(7),
                                rs.getString(8),
                                rs.getDouble(9),
                                rs.getString(10),
                                rs.getString(11)
                        )
                ));
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public void updateQuantity(Cart cart) {
        try {
            String sql = "update Cart set Quantity = ? where CartID = ?";
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, cart.getQuantity());
            ps.setInt(2, cart.getCartId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteCart(int cartId) {
        try {
            String sql = "delete from Cart where CartID = ?";
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, cartId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteCart(int productId, int customerId) {
        try {
            String sql = "delete from Cart where ProductID = ? and CustomerID = ?";
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, productId);
            ps.setInt(2, customerId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void deleteCarts(List<Cart> carts){
        try {
            String sql = "delete from Cart where CartID in ();";
            String in = "(";
            for (int i = 0; i < carts.size(); i++) {
                if (i == carts.size() - 1) {
                    in += carts.get(i).getCartId();
                } else {
                    in += carts.get(i).getCartId() + ",";
                }
            }
            in += ")";
            sql = sql.replaceFirst("\\(\\)", in);
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void order(int userId) {
        try {
            List<Cart> carts = new DAO().getCartOfCustomer(userId);
            double totalPrice = 0;
            for (Cart cart : carts) {
                totalPrice += cart.getQuantity() * cart.getProducts().getPrice();
            }
            totalPrice *= 1.1;
            String sql = "insert into Orders(CustomerID, OrderDate, TotalAmount, Status) VALUES ((select CustomerID from Customers where UserID = ?), ?, ?, ?)";
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, userId);
            ps.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            ps.setDouble(3, totalPrice);
            ps.setString(4, "Pending");
            ps.executeUpdate();
            ps.getGeneratedKeys().next();
            int orderId = ps.getGeneratedKeys().getInt(1);
            sql = "";
            for (int i = 0; i < carts.size(); i++) {
                sql += "insert into OrderDetails(OrderID, ProductID, Quantity, Price) VALUES (?, ?, ?, ?);";
            }
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            for (int i = 0; i < carts.size(); i++) {
                ps.setInt(i * 4 + 1, orderId);
                ps.setInt(i * 4 + 2, carts.get(i).getProductID());
                ps.setDouble(i * 4 + 3, carts.get(i).getQuantity());
                ps.setDouble(i * 4 + 4, carts.get(i).getProducts().getPrice());
            }
            ps.executeUpdate();
            deleteCarts(carts);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public List<Order> getOrdersWithUser(Users user) {
        try {
            int CustomerId = getCustomerId(user.getUserID());
            List<OrderDetail> orderDetails = new ArrayList<>();
            List<Products> products = getAllProducts();
            String sql = "select OrderDetails.* from OrderDetails inner join dbo.Orders O on O.OrderID = OrderDetails.OrderID where CustomerID = ?";
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, CustomerId);
            rs = ps.executeQuery();
            while (rs.next()) {
                orderDetails.add(new OrderDetail(
                        rs.getInt(1),
                        rs.getInt(2),
                        getProduct(rs.getInt(3), products),
                        rs.getInt(4),
                        rs.getInt(5)
                ));
            }

            sql = "select * from Orders where CustomerID = ?";
            List<Order> orders = new ArrayList<>();
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, CustomerId);
            rs = ps.executeQuery();
            while (rs.next()) {
                orders.add(new Order(
                        rs.getInt(1),
                        user,
                        rs.getTimestamp(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        new ArrayList<OrderDetail>()
                ));
            }
            for (Order order : orders) {
                for (OrderDetail orderDetail : orderDetails) {
                    if (order.getOrderId() == orderDetail.getOrderId()) {
                        order.getOrderDetails().add(orderDetail);
                    }
                }
            }
            return orders;
        } catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    public List<Order> getAllOrders(){
        try {
            List<Users> users = getAllUser();
            List<OrderDetail> orderDetails = new ArrayList<>();
            List<Products> products = getAllProducts();
            String sql = "select * from OrderDetails";
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                orderDetails.add(new OrderDetail(
                        rs.getInt(1),
                        rs.getInt(2),
                        getProduct(rs.getInt(3), products),
                        rs.getInt(4),
                        rs.getInt(5)
                ));
            }

            sql = "select * from Orders";
            List<Order> orders = new ArrayList<>();
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                orders.add(new Order(
                        rs.getInt(1),
                        getUser(rs.getInt(2), users),
                        rs.getTimestamp(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        new ArrayList<>()
                ));
            }
            for (Order order : orders) {
                for (OrderDetail orderDetail : orderDetails) {
                    if (order.getOrderId() == orderDetail.getOrderId()) {
                        order.getOrderDetails().add(orderDetail);
                    }
                }
            }
            return orders;
        } catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    public Products getProduct(int productId, List<Products> products) {
        for (Products p : products) {
            if (p.getProductID() == productId) {
                return p;
            }
        }
        return null;
    }
    public Users getUser(int userId, List<Users> users) {
        for (Users user : users) {
            if (user.getUserID() == userId) {
                return user;
            }
        }
        return null;
    }
    public void updateOrderStatus(String OrderId, String status){
        try {
            String sql = "update Orders set Status = ? where OrderID = ?";
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, status);
            ps.setString(2, OrderId);
            ps.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        // Tạo đối tượng DAO
        DAO dao = new DAO();

        // Dữ liệu test
        List<Users> list = dao.getAllUser();
        System.out.println(list);
    }
}
