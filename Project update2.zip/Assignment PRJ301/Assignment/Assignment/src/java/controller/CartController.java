package controller;

import dal.DAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Cart;
import model.Products;
import model.Users;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/cart")
public class CartController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String productId = req.getParameter("productId");
        String quantity = req.getParameter("quantity");
        if (req.getSession().getAttribute("acc") == null) {
            Products products = new DAO().getProductByCID(productId);
            if (req.getSession().getAttribute("cart") == null){
                ArrayList<Cart> cart = new ArrayList<>();
                cart.add(new Cart(Integer.parseInt(productId), Integer.parseInt(quantity), new Timestamp(System.currentTimeMillis()), products));
                req.getSession().setAttribute("cart", cart);
            } else {
                List<Cart> cart = (ArrayList<Cart>) req.getSession().getAttribute("cart");
                boolean mark = true;
                for (int i = 0; i < cart.size(); i++) {
                    if (cart.get(i).getProductID() == Integer.parseInt(productId)) {
                        cart.get(i).setQuantity(cart.get(i).getQuantity() + Integer.parseInt(quantity));
                        mark = false;
                        break;
                    }
                }
                if (mark) {
                    cart.add(new Cart(Integer.parseInt(productId), Integer.parseInt(quantity), new Timestamp(System.currentTimeMillis()), products));
                }
                req.getSession().setAttribute("cart", cart);
            }
        } else {
            Users user = (Users) req.getSession().getAttribute("acc");
            int customerId = new DAO().getCustomerId(user.getUserID());
            Cart cart = new Cart(customerId, Integer.parseInt(productId), Integer.parseInt(quantity), new Timestamp(System.currentTimeMillis()));
            List<Cart> userCart = new DAO().getCartOfCustomer(user.getUserID());
            boolean mark = true;
            for (int i = 0; i < userCart.size(); i++) {
                if (userCart.get(i).getProductID() == Integer.parseInt(productId)) {
                    userCart.get(i).setQuantity(userCart.get(i).getQuantity() + Integer.parseInt(quantity));
                    new DAO().updateQuantity(userCart.get(i));
                    mark = false;
                    break;
                }
            }
            if (mark) {
                new DAO().add2Cart(cart);
            }
        }
        resp.sendRedirect(req.getContextPath() + "/home");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action == null){
            req.getRequestDispatcher("/Cart.jsp").forward(req, resp);
        } else {
            if (action.equals("plus") || action.equals("minus")) {
                String productId = req.getParameter("productId");
                Users user = (Users) req.getSession().getAttribute("acc");
                List<Cart> carts;
                if(user == null){
                    carts = (ArrayList<Cart>) req.getSession().getAttribute("cart");
                } else {
                    carts = new DAO().getCartOfCustomer(user.getUserID());
                }
                for (Cart cart : carts) {
                    if (cart.getProductID() == Integer.parseInt(productId)) {
                        if (action.equals("plus")) {
                            cart.setQuantity(cart.getQuantity() + 1);
                        } else {
                            if (cart.getQuantity() == 1){
                                if(user != null){
                                    new DAO().deleteCart(cart.getProductID(), cart.getCustomerID());
                                } else {
                                    carts.remove(cart);
                                }
                            }
                            cart.setQuantity(cart.getQuantity() - 1);
                        }
                        if(user != null){
                            new DAO().updateQuantity(cart);
                        }
                        break;
                    }
                }
            }
            else {
                Users user = (Users) req.getSession().getAttribute("acc");
                if (user != null){
                    new DAO().deleteCart(Integer.parseInt(req.getParameter("cartId")));
                } else {
                    String productId = req.getParameter("productId");
                    List<Cart> carts = (ArrayList<Cart>) req.getSession().getAttribute("cart");
                    for (int i = 0; i < carts.size(); i++) {
                        if(carts.get(i).getProductID() == Integer.parseInt(productId)){
                            carts.remove(i);
                            break;
                        }
                    }
                }
            }
            resp.sendRedirect(req.getContextPath() + "/cart");
        }
    }
}
