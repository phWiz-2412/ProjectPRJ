package controller;

import dal.DAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Users;

import java.io.IOException;

@WebServlet("/order")
public class OrderController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (req.getSession().getAttribute("acc") == null){
            resp.sendRedirect("login");
        } else {
            Users user = (Users) req.getSession().getAttribute("acc");
            new DAO().order(user.getUserID());
            resp.sendRedirect(req.getContextPath() + "/cart");
        }
    }
}
